from .mnist import load_data
from .noisy_mnist import load_data
from .cifar10 import load_data
from .noisy_cifar10 import load_data