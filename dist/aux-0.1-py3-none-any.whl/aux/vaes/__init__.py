from .dense_vae import DenseVAE
from .conv_vae import ConvVAE