from .mnist import load_data
from .cifar10 import load_data
from .fmnist import load_data